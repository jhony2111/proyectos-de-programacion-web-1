
<script src="../js/sweetalert2@10.js"></script>
.
<?php
require "../config/conexion.php";
$cedula = $_POST["cedula"];
$distancia = $_POST["distancia"];
$sql = "UPDATE carrera_itfip SET 
distancia='".$distancia."' WHERE documento=".$cedula."";
if ($conexion->query($sql))
{
    echo  "<script>
    Swal.fire({
      title: 'actualizado CORRECTAMENTE',
      icon: 'success',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../actualizar.html';
      }
    });
  </script>";
}
   else
{
    echo "<script>
    Swal.fire({
      title: 'Error actualizando',
      icon: 'error',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../actualizar.html';
      }
    });
  </script>";
}
?>