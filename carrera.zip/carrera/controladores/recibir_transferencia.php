<script src="../js/sweetalert2@10.js"></script>
.
<?php
require "../config/conexion.php";
$cedula = $_POST["cedula"];
$nombre = $_POST["nombre"];
$distancia = $_POST["distancia"];
    $sql = "INSERT INTO carrera_itfip
    (documento, nombre, distancia, fecha_sys) VALUES
    (".$cedula.",'".$nombre."','".$distancia."',now() )";
if ($conexion->query($sql))


{
    echo "<script>
    Swal.fire({
      title: 'inscripcion exitosa',
      icon: 'success',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../inscripcion.html';
      }
    });
  </script>";
}
   else
{
    echo "<script>
    Swal.fire({
      title: 'error en la inscripcion',
      icon: 'error',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../inscripcion.html';
      }
    });
  </script>";
}

?>