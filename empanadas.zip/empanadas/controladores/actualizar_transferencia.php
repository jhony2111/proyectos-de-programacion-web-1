
<script src="../js/sweetalert2@10.js"></script>
.
<?php
require "../config/conexion.php";
$cod = $_POST["cod"];
$tipo_gaseosa = $_POST["tipo_gaseosa"];
$valor_pagado = $_POST["valor_pagado"];
$sql = "UPDATE registros SET tipo_gaseosa=".$tipo_gaseosa.", valor_pagado=".$valor_pagado." WHERE cod=".$cod."";
if ($conexion->query($sql))
{
    echo  "<script>
    Swal.fire({
      title: 'actualizado CORRECTAMENTE',
      icon: 'success',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../actualizar.html';
      }
    });
  </script>";
}
   else
{
    echo "<script>
    Swal.fire({
      title: 'Error actualizando',
      icon: 'error',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../actualizar.html';
      }
    });
  </script>";
}
?>