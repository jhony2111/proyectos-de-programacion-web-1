<?php
require "../config/conexionn.php";
$origen = $_POST["origen"];
$valor = $_POST["valor"];
$celular = $_POST["celular"];
$sql = "INSERT INTO transferenciass  (origen, valor, celular, fecha_sys) VALUES
('$origen','$valor','$celular', now() )";
if ($conexion->query($sql))
{
    echo "transferencia exitosa";
}
   else
{
    echo "error en la transaccion";
}
?>