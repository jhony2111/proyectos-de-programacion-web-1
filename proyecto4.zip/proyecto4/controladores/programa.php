<?php
include "config/conexion.php";
$sql = "SELECT id , valor , tipo_entrada 
FROM entrada
WHERE 1";


foreach($conexion->query($sql) as $fila)
{


      $id = $fila[0];
      $valor = $fila[1];
      $tipo_entrada = $fila[2];
    

    print " <option value= '".$id."'>".$tipo_entrada." </option>";
}    
   
   
   
    


?>