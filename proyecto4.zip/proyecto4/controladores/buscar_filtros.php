

<?php
include "config/conexion.php";
$cantidad = $_POST["cantidad"];

$sql = "SELECT total, cantidad, fecha_sys
    FROM vender
    WHERE cantidad like '%".$cantidad."%'";
$i=1;
foreach ($conexion->query($sql) as $row) {

  $cantidad = $row["cantidad"];
   $total  = $row["total"];
    $fecha_sys = $row ["fecha_sys"];
print "
 <tr>
  <td> $i </td> 
  <td>$total </td>
  <td>$cantidad</td>
  <td> $fecha_sys </td>
    </tr>
     ";


;
$i++;
}
?>