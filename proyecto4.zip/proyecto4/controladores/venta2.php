<script src="../js/sweetalert2@10.js"></script>
.
<?php
require "../config/conexion.php";

$tipo_entrada = $_POST["tipo_entrada"];
$valor = $_POST("valor");
    $sql = "INSERT INTO entrada
    (valor,tipo_entrada ,fecha_sys) VALUES
    (".$valor.", ".$tipo_entrada." ,now() )";
if ($conexion->query($sql))


{
    echo "<script>
    Swal.fire({
      title: 'venta exitosa',
      icon: 'success',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../vender.html';
      }
    });
  </script>";
}
else
{
    echo "<script>
    Swal.fire({
      title: 'Error en el registro',
      icon: 'error',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../vender.html';
      }
    });
  </script>";
}

?>