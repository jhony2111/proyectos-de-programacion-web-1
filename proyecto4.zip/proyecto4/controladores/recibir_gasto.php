<script src="../js/sweetalert2@10.js"></script>
.
<?php
require "../config/conexion.php";


$gasto = $_POST["gasto"];

    $sql = "INSERT INTO gastos
    (gasto,fecha_sys) VALUES
    (".$gasto." ,now() )";
if ($conexion->query($sql))


{
    echo "<script>
    Swal.fire({
      title: 'registro de gasto exitoso',
      icon: 'success',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../gastos.html';
      }
    });
  </script>";
}
   else
{
    echo "<script>
    Swal.fire({
      title: 'Error en el registro',
      icon: 'error',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../gastos.html';
      }
    });
  </script>";
}

?>