<?php
require "../config/conexion.php";
$celular_destino = $_POST["celular"];
$valor = $_POST["valor"];
$pin = $_POST["pin"];
$sql = "INSERT INTO transferencias
(celular_destino, valor, fecha_sys) VALUES
('".$celular_destino."',".$valor.",now() )";
if ($conexion->query($sql))
{
    echo "transferencia exitosa";
}
   else
{
    echo "error en la transaccion";
}
?>