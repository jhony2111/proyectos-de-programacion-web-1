<?php
include "config/conexion.php";
$sql = "SELECT id , nombre 
FROM programas
WHERE 1";


foreach($conexion->query($sql) as $fila)
{


      $id = $fila[0];
      $nombre = $fila[1];
    
    

    print " <option value= '".$id."'>".$nombre." </option>";
}    
   
   
   
    


?>