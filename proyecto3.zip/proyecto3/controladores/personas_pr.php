<?php
include "config/conexion.php";
$sql = "SELECT id, celular_destino, valor, fecha_sys
FROM transferencias 
WHERE 1";


foreach($conexion->query($sql) as $fila){


    
    $id =$fila['id'];
    $celular_destino = $fila['celular_destino'];
    $valor =$fila ['valor'];
    $fecha_sys = $fila ['fecha_sys'];

    print "<tr>
 
    <td> ".$id." </td>
    <td> ".$celular_destino." </td>
    <td> ".$valor."</td>
    <td>".$fecha_sys." </td>
    </tr>
    ";
    
   
   
   
    }


?>