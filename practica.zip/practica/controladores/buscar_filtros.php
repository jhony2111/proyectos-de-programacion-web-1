

<?php
include "config/conexion.php";

if(isset($_POST["mascota"]))
{
$mascota = $_POST["mascota"];

$sql = "SELECT nombre_mascota, fecha_sys
    FROM mascota
    WHERE nombre_mascota like '%".$mascota."%'";
$i=1;

foreach ($conexion->query($sql) as $row) {

  $mascota = $row["nombre_mascota"];
    $fecha_sys = $row ["fecha_sys"];
print "
 <tr>
  <td> $i </td> 
  <td>$mascota </td>
  
  <td> $fecha_sys </td>
    </tr>
     ";


;
$i++;
}
}
?>