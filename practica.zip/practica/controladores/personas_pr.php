<?php
include "config/conexion.php";
$sql = "SELECT id, subtotal, iva19,total, cantidad, val_unit, fecha_sys
FROM vender 
WHERE 1";


foreach($conexion->query($sql) as $fila){


    
    $id =$fila['id'];
    $subtotal = $fila['subtotal'];
    $iva19 =$fila ['iva19'];
    $total =$fila['total'];
    $cantidad = $fila['cantidad'];
    $val_unit =$fila ['val_unit'];
    $fecha_sys = $fila ['fecha_sys'];

    print "<tr>
 
    <td> ".$id." </td>
    <td> ".$subtotal." </td>
    <td> ".$iva19."</td>
    <td> ".$total." </td>
    <td> ".$cantidad."</td>
    <td> ".$val_unit."</td>
    <td>".$fecha_sys." </td>

    </tr>
    ";
    
   
   
   
    }


?>