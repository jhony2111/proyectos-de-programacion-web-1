<script src="../js/sweetalert2@10.js"></script>
.
<?php
require "../config/conexion.php";

$tipo_entrada = $_POST["tipo_entrada"];
$cantidad = $_POST["cantidad"];
$subtotal = $tipo_entrada * $cantidad;
$iva = $subtotal * 0.19;
$total = $subtotal + $iva;
    $sql = "INSERT INTO vender
    (subtotal, iva19, total, cantidad, val_unit ,fecha_sys) VALUES
    (".$subtotal.",".$iva.",".$total.",".$cantidad.", ".$tipo_entrada." ,now() )";
if ($conexion->query($sql))


{
    echo "<script>
    Swal.fire({
      title: 'venta exitosa',
      icon: 'success',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../vender.html';
      }
    });
  </script>";
}
   else
{
    echo "<script>
    Swal.fire({
      title: 'Error en el registro',
      icon: 'error',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../vender.html';
      }
    });
  </script>";
}

?>