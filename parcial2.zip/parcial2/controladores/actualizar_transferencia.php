
<script src="../js/sweetalert2@10.js"></script>
.
<?php
require "../config/conexion.php";
$idac= $_POST["idac"];
$tipo_entrada = $_POST["tipo_entrada"];
$cantidad = $_POST["cantidad"];
$subtotal = $tipo_entrada * $cantidad;
$iva = $subtotal * 0.19;
$total = $subtotal + $iva;
$sql = "UPDATE vender SET 
subtotal=".$subtotal.",iva19=".$iva.",total=".$total.",cantidad=".$cantidad.", val_unit=".$tipo_entrada." WHERE id=".$idac."";
if ($conexion->query($sql))
{
    echo  "<script>
    Swal.fire({
      title: 'actualizado CORRECTAMENTE',
      icon: 'success',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../actualizar.html';
      }
    });
  </script>";
}
   else
{
    echo "<script>
    Swal.fire({
      title: 'Error actualizando',
      icon: 'error',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../actualizar.html';
      }
    });
  </script>";
}
?>