<?php
require "../config/conexionn.php";
$nombre = $_POST["nombre"];
$edad = $_POST["edad"];
$celular = $_POST["celular"];
$email = $_POST["email"];
$sql = "INSERT INTO registrados (nombre, edad,celular, email, fecha_sys) VALUES ('$nombre', '$edad', '$celular', '$email', now() )" ;
if ($edad>17 ) {
    echo "bienvenido a onlyfans";

}
else {
    die ("no puedes registrarte porque eres menor de edad");
} 
if ($conexion->query($sql))
{
    echo " cuenta creada";
}
   else
{
    echo "no se pudo crear usuario";
}
?>