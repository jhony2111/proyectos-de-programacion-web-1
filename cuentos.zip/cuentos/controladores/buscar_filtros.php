

<?php
include "config/conexion.php";
$cuento = $_POST["cuento"];

$sql = "SELECT nombre_mascota, fecha_sys
    FROM mascota
    WHERE mascota like '%".$mascota."%'";
$i=1;
foreach ($conexion->query($sql) as $row) {

  $mascota = $row["mascota"];
    $fecha_sys = $row ["fecha_sys"];
print "
 <tr>
  <td> $i </td> 
  <td>$mascota </td>
  
  <td> $fecha_sys </td>
    </tr>
     ";


;
$i++;
}
?>