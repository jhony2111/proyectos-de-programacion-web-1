<script src="../js/sweetalert2@10.js"></script>
.
<?php
require "../config/conexion.php";
$tipo = $_POST["tipo"];
$valor_pagado = $_POST["valor_pagado"];

$sql = "INSERT INTO registros
(tip, valor_pagado, fecha_sys) VALUES
('".$tipo."',".$valor_pagado.",now() )";
if ($conexion->query($sql))
{
   echo "<script>
    Swal.fire({
      title: 'registro exitoso',
      icon: 'success',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../index.html';
      }
    });
  </script>";
}
   else
{
    echo "<script>
    Swal.fire({
      title: 'Error en la compra',
      icon: 'error',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Aceptar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = '../index.html';
      }
    });
  </script>";
}
?>